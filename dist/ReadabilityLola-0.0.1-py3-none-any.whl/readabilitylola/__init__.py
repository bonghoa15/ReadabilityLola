from readabilitylola.hindi import Hindi
from readabilitylola.bahasa import Bahasa